# CRUD_Operation
 This is simple project about CRUD operation using Dapper
